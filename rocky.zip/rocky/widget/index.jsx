export const refreshFrequency = false;
export const command = "echo ''";
export const className = `
  position: fixed;
  bottom: 80px;
  left: 50%;
  transform: translateX(-50%);
  z-index: 9999;
  cursor: pointer;
  animation: float 3s ease-in-out infinite;
  @keyframes float {
    0%, 100% { transform: translateX(-50%) translateY(0); }
    50% { transform: translateX(-50%) translateY(-6px); }
  }
  &:hover {
    animation: none;
    transform: translateX(-50%) translateY(-10px);
  }
`;
export const render = () => (
  <a href="https://claude.ai" style={{display:'block'}}>
    <svg width="120" height="140" viewBox="0 0 680 520" xmlns="http://www.w3.org/2000/svg">
      <ellipse cx="340" cy="490" rx="170" ry="16" fill="#000" opacity="0.3"/>
      <path d="M255 295 L240 310 L225 350 L210 390 L200 430 L195 455 L210 470 L235 468 L240 450 L238 420 L242 380 L255 340 L270 305" fill="#8B6F47" stroke="#5C4A2E" strokeWidth="2" strokeLinejoin="round"/>
      <path d="M195 455 L185 468 L210 475 L235 468" fill="#7A6040" stroke="#5C4A2E" strokeWidth="2" strokeLinejoin="round"/>
      <path d="M425 295 L440 310 L455 350 L470 390 L480 430 L485 455 L470 470 L445 468 L440 450 L442 420 L438 380 L425 340 L410 305" fill="#8B6F47" stroke="#5C4A2E" strokeWidth="2" strokeLinejoin="round"/>
      <path d="M485 455 L495 468 L470 475 L445 468" fill="#7A6040" stroke="#5C4A2E" strokeWidth="2" strokeLinejoin="round"/>
      <path d="M275 300 L258 325 L240 365 L228 405 L222 440 L220 460 L235 472 L258 470 L260 448 L258 415 L265 375 L278 335 L290 308" fill="#9A7D55" stroke="#5C4A2E" strokeWidth="2" strokeLinejoin="round"/>
      <path d="M220 460 L212 472 L235 478 L258 470" fill="#8B6F47" stroke="#5C4A2E" strokeWidth="2" strokeLinejoin="round"/>
      <path d="M405 300 L422 325 L440 365 L452 405 L458 440 L460 460 L445 472 L422 470 L420 448 L422 415 L415 375 L402 335 L390 308" fill="#9A7D55" stroke="#5C4A2E" strokeWidth="2" strokeLinejoin="round"/>
      <path d="M460 460 L468 472 L445 478 L422 470" fill="#8B6F47" stroke="#5C4A2E" strokeWidth="2" strokeLinejoin="round"/>
      <path d="M328 310 L325 345 L322 385 L318 425 L315 455 L330 472 L352 472 L365 455 L362 425 L358 385 L355 345 L352 310" fill="#A8894F" stroke="#5C4A2E" strokeWidth="2" strokeLinejoin="round"/>
      <path d="M315 455 L308 470 L330 478 L352 478 L372 470 L365 455" fill="#9A7D55" stroke="#5C4A2E" strokeWidth="2" strokeLinejoin="round"/>
      <path d="M260 220 L260 195 C260 160, 280 140, 310 135 L370 135 C400 140, 420 160, 420 195 L420 220" fill="#B89B60" stroke="#5C4A2E" strokeWidth="2" strokeLinejoin="round"/>
      <path d="M265 218 L265 270 C265 300, 280 315, 310 320 L370 320 C400 315, 415 300, 415 270 L415 218 Z" fill="#A8894F" stroke="#5C4A2E" strokeWidth="2" strokeLinejoin="round"/>
      <line x1="262" y1="220" x2="418" y2="220" stroke="#5C4A2E" strokeWidth="1.5"/>
      <circle cx="315" cy="185" r="4" fill="#5C4A2E" opacity="0.6"/>
      <circle cx="365" cy="185" r="4" fill="#5C4A2E" opacity="0.6"/>
      <circle cx="316.5" cy="183.5" r="1.2" fill="#D4C4A0" opacity="0.7"/>
      <circle cx="366.5" cy="183.5" r="1.2" fill="#D4C4A0" opacity="0.7"/>
      <path d="M325 202 Q340 214, 355 202" fill="none" stroke="#5C4A2E" strokeWidth="1.8" strokeLinecap="round" opacity="0.45"/>
      <line x1="280" y1="250" x2="305" y2="245" stroke="#8B7545" strokeWidth="1" opacity="0.6"/>
      <line x1="375" y1="255" x2="400" y2="265" stroke="#8B7545" strokeWidth="1" opacity="0.6"/>
      <line x1="290" y1="290" x2="315" y2="285" stroke="#8B7545" strokeWidth="1" opacity="0.6"/>
      <line x1="370" y1="290" x2="395" y2="300" stroke="#8B7545" strokeWidth="1" opacity="0.6"/>
      <line x1="400" y1="240" x2="412" y2="260" stroke="#8B7040" strokeWidth="1" opacity="0.4"/>
      <line x1="402" y1="248" x2="410" y2="268" stroke="#8B7040" strokeWidth="1" opacity="0.4"/>
      <line x1="398" y1="270" x2="410" y2="295" stroke="#8B7040" strokeWidth="1" opacity="0.4"/>
    </svg>
  </a>
);
